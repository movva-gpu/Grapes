<header>
        <nav>
            <img src="" alt="Logo">
            <div class="links">
            <a href="index.php">
                            <div class="h">
                                <span class="main">Accueil</span>
                                
                            </div>
                        </a>
                        <a href="">
                            <div class="h">
                                <span class="main">Les jardins</span>
                                
                            </div>
                        </a>
                        <a href="">
                            <div class="h">
                                <span class="main">Contactez nous</span>
                                
                            </div>
                        </a>
                        
              <div class="co-ins">
        <a href="connexion.php">
        <div class="h">
            <span class="main">Connexion</span>
            
        </div>
    </a>
    /
    <a href="inscription.php">
        <div class="h">
            <span class="main">Inscription</span>
            
        </div>
    </a>
    </div>    
</div>
        </nav>
    </header>
    <div class="hero">
    <div class="hero-content">
        <h1>GRAPES</h1>
        <p>Le co-jardinage c’est maintenant !</p>
    </div>
    <svg class="wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="white" fill-opacity="1" d="M0,224L60,186.7C120,149,240,75,360,85.3C480,96,600,192,720,208C840,224,960,160,1080,149.3C1200,139,1320,181,1380,202.7L1440,224L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
    </svg>
</div>