<footer>
    <div class="footer">
        <div class="f1">
            <h3>Sites crée par :</h3> <br>
            <p>L'Agence Blossom Media</p>
            <p>Thomas</p>
            <p>Hamza</p>
            <p>Eglantine</p>
            <p>Noam</p>
            <p>Danyella</p>
        </div>
        <div class="f3">
            <h3>Credits</h3> <br>
            <p>mentions legales</p>
            <p>Contact</p>
            <p>A propos</p>
        </div>
        <div class="f2">
            <h3>Nous contacter :</h3> <br>
            <img src="images/instagram (3).png" alt="insta">
            <img src="images/facebook (2).png" alt="fb">
            <img src="images/twitter (3).png" alt="x">
        </div>
</footer>